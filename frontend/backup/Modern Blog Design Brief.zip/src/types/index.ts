export interface User {
  id: string;
  username: string;
  name: string;
  bio: string;
  avatar: string;
}

export interface Post {
  id: string;
  authorId: string;
  title: string;
  date: string;
  image: string;
  category: string;
  excerpt: string;
  content: string[];
  author?: User;
}

export interface Subscription {
  userId: string;
  subscribedToId: string;
}
