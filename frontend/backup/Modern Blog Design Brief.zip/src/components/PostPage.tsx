import { ImageWithFallback } from './figma/ImageWithFallback';
import { Newsletter } from './Newsletter';
import { ArrowLeft } from 'lucide-react';

interface Post {
  id: number;
  title: string;
  date: string;
  image: string;
  category: string;
  excerpt: string;
  content: string[];
}

interface PostPageProps {
  post: Post;
  onBack: () => void;
}

export function PostPage({ post, onBack }: PostPageProps) {
  return (
    <div className="min-h-screen bg-white">
      <article className="max-w-4xl mx-auto px-6 py-12">
        {/* Back button */}
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors mb-8"
          style={{ fontFamily: 'Inter, sans-serif' }}
        >
          <ArrowLeft size={20} />
          Back to all posts
        </button>

        {/* Category and date */}
        <div className="flex items-center gap-3 mb-6">
          <span 
            className="px-3 py-1 rounded-full text-white"
            style={{ 
              backgroundColor: 'var(--accent-blog)',
              fontFamily: 'Inter, sans-serif'
            }}
          >
            {post.category}
          </span>
          <time className="text-gray-500" style={{ fontFamily: 'Inter, sans-serif' }}>
            {post.date}
          </time>
        </div>

        {/* Title */}
        <h1 
          style={{ 
            fontFamily: 'Playfair Display, serif',
            fontSize: '3rem',
            lineHeight: '1.2'
          }}
          className="mb-10 tracking-tight"
        >
          {post.title}
        </h1>

        {/* Featured image - full width of content */}
        <div className="relative overflow-hidden aspect-[16/9] mb-12 -mx-6 md:mx-0">
          <ImageWithFallback 
            src={post.image}
            alt={post.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Article content */}
        <div 
          className="prose prose-lg max-w-none"
          style={{ fontFamily: 'Inter, sans-serif' }}
        >
          {post.content.map((paragraph, index) => (
            <p 
              key={index} 
              className="mb-6 text-gray-800"
              style={{ 
                lineHeight: '1.9',
                fontSize: '1.125rem'
              }}
            >
              {paragraph}
            </p>
          ))}
        </div>

        {/* Newsletter CTA */}
        <Newsletter />
      </article>
    </div>
  );
}
