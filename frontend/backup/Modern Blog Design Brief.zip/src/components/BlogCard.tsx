import { ImageWithFallback } from './figma/ImageWithFallback';

interface BlogCardProps {
  title: string;
  date: string;
  image: string;
  category: string;
  onClick: () => void;
}

export function BlogCard({ title, date, image, category, onClick }: BlogCardProps) {
  return (
    <article 
      onClick={onClick}
      className="group cursor-pointer"
    >
      <div className="relative overflow-hidden aspect-[4/3] mb-5">
        <ImageWithFallback 
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
      </div>
      <div className="flex items-center gap-3 mb-3">
        <span 
          className="px-2 py-1 rounded-full text-white"
          style={{ 
            backgroundColor: 'var(--accent-blog)',
            fontFamily: 'Inter, sans-serif',
            fontSize: '0.875rem'
          }}
        >
          {category}
        </span>
        <time 
          className="text-gray-500" 
          style={{ 
            fontFamily: 'Inter, sans-serif',
            fontSize: '0.875rem'
          }}
        >
          {date}
        </time>
      </div>
      <h3 
        style={{ fontFamily: 'Playfair Display, serif' }}
        className="group-hover:text-gray-600 transition-colors tracking-tight"
      >
        {title}
      </h3>
    </article>
  );
}
