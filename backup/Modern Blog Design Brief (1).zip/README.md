
  # Modern Blog Design Brief

  This is a code bundle for Modern Blog Design Brief. The original project is available at https://www.figma.com/design/jJnDp1HRE52Vnu6Mm1ardZ/Modern-Blog-Design-Brief.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  